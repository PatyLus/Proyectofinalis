# baja_am_svl.py (Componente Baja)

from data_access import AdultoMayorDAO

dao = AdultoMayorDAO()

def baja_adulto_mayor_if_bam(id_interno: int) -> bool:
    """
    IF BAM: Interfaz para la Baja de Adulto Mayor.
    Realiza la baja lógica (cambio de estado).
    """
    
    adulto = dao.obtener_por_id(id_interno)
    if not adulto:
        print(f"Error: ID {id_interno} no encontrado. ❌")
        return False
        
    # Ejecutar la operación de desactivación
    if dao.desactivar(id_interno):
        print(f"✅ Baja exitosa (estado Inactivo) para ID {id_interno}.")
        return True
        
    return False