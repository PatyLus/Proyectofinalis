# data_access.py
# Simulación de la tabla 'Adultos Mayores' y su persistencia
adultos_mayores_db = {} 

class AdultoMayorDAO:
    """Clase de Acceso a Datos (DAO) para la entidad AdultoMayor."""

    def insertar(self, adulto_mayor):
        """Implementa la inserción en la base de datos."""
        if adulto_mayor.id_interno in adultos_mayores_db:
            raise ValueError("ID duplicado.")
        adultos_mayores_db[adulto_mayor.id_interno] = adulto_mayor
        return True

    def desactivar(self, id_interno):
        """Implementa la baja lógica/eliminación, actualizando el estado."""
        if id_interno in adultos_mayores_db:
            adultos_mayores_db[id_interno].cambiar_estado("Inactivo")
            return True
        return False

    def obtener_por_id(self, id_interno):
        return adultos_mayores_db.get(id_interno)