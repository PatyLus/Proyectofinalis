# gestion_adulto_mayor.py (Componente Gestion del Adulto Mayor.py)

from datetime import date
from alta_am_svl import alta_adulto_mayor_if_aam
from baja_am_svl import baja_adulto_mayor_if_bam
from data_access import AdultoMayorDAO # Para fines de consulta en el ejemplo

def gestionar_alta(id_interno: int, nombre: str, fnac: date, fingreso: date, tratamiento: str):
    """IF GAM: Expone la funcionalidad de Alta al sistema."""
    print(f"\n[IF GAM] Solicitando ALTA para {nombre}...")
    return alta_adulto_mayor_if_aam(id_interno, nombre, fnac, fingreso, tratamiento)

def gestionar_baja(id_interno: int):
    """IF GAM: Expone la funcionalidad de Baja al sistema."""
    print(f"\n[IF GAM] Solicitando BAJA para ID {id_interno}...")
    return baja_adulto_mayor_if_bam(id_interno)

# --- EJECUCIÓN DE PRUEBA ---
if __name__ == "__main__":
    
    # 1. ALTA Exitosa
    gestionar_alta(
        id_interno=102, 
        nombre="Pedro Martínez", 
        fnac=date(1943, 7, 28), 
        fingreso=date(2025, 9, 10), 
        tratamiento="Diabetes"
    )

    # 2. ALTA Duplicada (debe fallar la validación interna del Alta AM.svl)
    gestionar_alta(
        id_interno=102, 
        nombre="Pedro Martínez 2", 
        fnac=date(1943, 7, 28), 
        fingreso=date(2025, 9, 10), 
        tratamiento="Diabetes"
    )

    # 3. BAJA Exitosa
    gestionar_baja(id_interno=102)

    # Verificación en la base de datos simulada
    print(f"\nEstado actual de ID 102 en la BD: {AdultoMayorDAO().obtener_por_id(102).estado}")

    # 4. BAJA Inexistente (debe fallar en el componente Baja)
    gestionar_baja(id_interno=999)