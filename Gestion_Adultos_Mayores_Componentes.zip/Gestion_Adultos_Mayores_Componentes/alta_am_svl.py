# alta_am_svl.py (Componente Alta AM.svl)

from datetime import date
from data_access import AdultoMayorDAO
from model import AdultoMayor 

dao = AdultoMayorDAO()

def alta_adulto_mayor_if_aam(id_interno: int, nombre: str, fecha_nacimiento: date, fecha_ingreso: date, tipo_tratamiento: str) -> bool:
    """
    IF AAM: Interfaz para el Alta de Adulto Mayor.
    Valida y registra un nuevo Adulto Mayor.
    """
    # Validaciones (RF-01: No futura, ID único)
    if fecha_nacimiento >= date.today() or fecha_ingreso > date.today():
        print("Error: Fechas inválidas (fecha futura).")
        return False
        
    if dao.obtener_por_id(id_interno):
        print(f"Error: Adulto Mayor con ID {id_interno} ya existe.")
        return False

    # Creación del objeto de negocio
    nuevo_adulto = AdultoMayor(
        id_interno=id_interno,
        nombre=nombre,
        fecha_nacimiento=fecha_nacimiento,
        fecha_ingreso=fecha_ingreso,
        tipo_tratamiento=tipo_tratamiento,
        enfermedades="No especificado",
        tipo_sangre="Desconocido"
    )

    # Inserción
    if dao.insertar(nuevo_adulto):
        print(f"✅ Alta exitosa: {nuevo_adulto.nombre} ({nuevo_adulto.id_interno})")
        return True
    
    return False