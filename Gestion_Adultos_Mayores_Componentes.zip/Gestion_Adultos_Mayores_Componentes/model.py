# model.py
from datetime import date
from typing import List, Optional

class AdultoMayor:
    """Representa al paciente, entidad central del sistema (RF-01)."""
    def __init__(self, id_interno: int, nombre: str, fecha_nacimiento: date, fecha_ingreso: date, tipo_tratamiento: str, enfermedades: str, tipo_sangre: str):
        self.id_interno = id_interno
        self.nombre = nombre
        self.fecha_nacimiento = fecha_nacimiento
        self.fecha_ingreso = fecha_ingreso
        self.tipo_tratamiento = tipo_tratamiento
        self.enfermedades = enfermedades
        self.tipo_sangre = tipo_sangre
        self.estado = "Activo" # Estado por defecto al crear

    def registrar(self):
        print(f"Adulto Mayor '{self.nombre}' registrado.")

    def cambiar_estado(self, nuevo_estado: str):
        """Método usado por el componente 'Baja' para la eliminación lógica."""
        self.estado = nuevo_estado
        print(f"Estado de {self.nombre} cambiado a {nuevo_estado}.")